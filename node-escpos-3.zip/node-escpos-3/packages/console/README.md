
## escpos-console

#### Console(handler = stdout)
```javascript
const escpos = require('escpos');
escpos.Console = require('escpos-console');

const debugDevice = new escpos.Console();
```
